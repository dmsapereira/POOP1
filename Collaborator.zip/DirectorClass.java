public class DirectorClass extends AbsCollaboratorClass {
	public DirectorClass(String name, int salary) {
		super(name, salary);
	}

}
