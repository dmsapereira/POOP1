public class AngryDirectorClass extends AbsAngryCollab {
	public AngryDirectorClass(String name, int salary) {
		super(name, salary);
	}

}
