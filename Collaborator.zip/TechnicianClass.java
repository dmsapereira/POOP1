public class TechnicianClass extends AbsCollaboratorClass {

	public TechnicianClass(String name,int index) {
		super(name,index);
	}
}
