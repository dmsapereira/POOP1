public class AngryActorClass extends AbsAngryCollab {

	public AngryActorClass(String name, int salary) {
		super(name, salary);
	}
}
