public class ActorClass extends AbsCollaboratorClass {
	public ActorClass(String name, int salary) {
		super(name,salary);
	}
}
